import React from 'react'
import google from '../assets/google.png'
import facebook from '../assets/facebook.png'

const Login = () => {
  return (
    <div className='login-component'>
      <div>
        <h1>Sing In</h1>
      </div>

      <div>
        <h3>
          Enter Mobile Number
        </h3>
      </div>

      <div className='get-otp-box'>
        <button className='button1'>
          +91 82109 - 00000
        </button>

        <button className='button2'>
          Get OTP
        </button>
      </div>

      <div>
        <p>Enter the valid no you will received otp!</p>
      </div>

      <div>
        <h2>
          Enter OTP
        </h2>
      </div>

      <div className='empty-buttons'>
        <button>.</button>
        <button>.</button>
        <button>.</button>
        <button>.</button>
      </div>

      <div>
        <p>
          Did Received OTP!<span> Resend?</span>
        </p>
      </div>

      <div className='submit-button'>
        <button>
          Submit
        </button>
      </div>

      <div className='singuptext'>
        <div className='singuptextdiv'>.</div>
        <div>
          Or sign up with
        </div>
        <div className='singuptextdiv'>.</div>
      </div>

      <div className='googlebutton'>
        <button>
        <img src={google} alt="" />  Google
        </button>
      </div>

      <div className='facebookbutton'>
        <button>
        <img src={facebook} alt="" />    Facebook
        </button>
      </div>

      <div>
        <p>
          Not a member? <span>Sign up now</span>
        </p>
      </div>

    </div>
  )
}

export default Login