import React from 'react'
import img from '../assets/Frame.png'
import heart from '../assets/heart.png'
import food from '../assets/food.png'
import { MdOutlineKeyboardArrowRight } from 'react-icons/md'


const Home = () => {
  return (
    <div className='home-component'>
      <div className='home-top-img'>
        <img src={img} alt="" />
      </div>
      <div className='home-bottom-content'>
        <div>
          <h1> Choose The  <span>One</span></h1>
        </div>

        <div>
          <p>
            Welcome to AGRLARK <br /> Resturant
          </p>
        </div>

        <div className='home-button-box'>
          <button>
            <div className='heart-img-box'>
              <img src={heart} alt="" />
            </div>

            <div style={{ display: 'flex', gap: "2rem", alignItems: 'center' }}>
              <h3>
                Swipe For Dating
              </h3>
              <div style={{ display: 'flex', gap: '-5px', position: 'relative' }}>
                <div style={{ marginRight: '-17px' }}>
                  <MdOutlineKeyboardArrowRight />
                </div>
                <div>
                  <MdOutlineKeyboardArrowRight />
                </div>
              </div>
            </div>

          </button>

          <button>
            <div className='heart-img-box heart-img-box1'>
              <img src={food} alt="" />
            </div>

            <div style={{ display: 'flex', gap: "3rem", alignItems: 'center' }}>
              <h3>
                Swipe For Food
              </h3>
              <div style={{ display: 'flex', gap: '-5px', position: 'relative' }}>
                <div style={{ marginRight: '-17px' }}>
                  <MdOutlineKeyboardArrowRight />
                </div>
                <div>
                  <MdOutlineKeyboardArrowRight />
                </div>
              </div>
            </div>

          </button>
        </div>
      </div>
    </div>
  )
}

export default Home