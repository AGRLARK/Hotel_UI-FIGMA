import { useState } from 'react'
import Home from './component/Home'
import Login from './component/Login'

function App() {
  return (
 <>
 <Home />
 { <Login /> }
 </>
  )
}

export default App
